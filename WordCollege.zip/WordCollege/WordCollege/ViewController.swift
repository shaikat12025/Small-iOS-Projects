//
//  ViewController.swift
//  WordCollege
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   
    @IBAction func changeBackgrounfToWhite(_ sender: Any) {
        view.backgroundColor = UIColor.white
        
        
    }
    
    
    @IBAction func changeBackgroundToBlack(_ sender: Any) {
        view.backgroundColor = UIColor.black
        
        
    }

    
    @IBAction func ChangeBackgroundToMagenta(_ sender: Any) {
        view.backgroundColor = UIColor.magenta
        
        
        
    }
    

}

