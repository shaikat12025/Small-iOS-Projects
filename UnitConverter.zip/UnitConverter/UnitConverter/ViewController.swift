//
//  ViewController.swift
//  UnitConverter
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate {
    
    
    @IBOutlet var temperatureRange: TemperatureRange!
    
    @IBOutlet weak var temperatureLabel: UILabel!
    
    @IBOutlet weak var celciusPicker: UIPickerView!
    
    let userDefaultsLastRowKey = "defaultCelciusPickerRow"
    
    private let converter = UnitConverter()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let row = initialPickerRow()
        celciusPicker.selectRow(row, inComponent: 0, animated: false)
        pickerView(celciusPicker, didSelectRow: row, inComponent: 0)
       
    }
    
    func initialPickerRow() -> Int {
        let savedRow = UserDefaults.standard.object(forKey: userDefaultsLastRowKey) as? Int
        
        if let row = savedRow{
            return row
        }
        else{
            return celciusPicker.numberOfRows(inComponent: 0)
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let celciusValue = temperatureRange.values[row]
            return "\(celciusValue) C"
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        displayConvertedTemperatureForRow(row: row)
        saveSelectedRow(row: row)
    }
    
    func displayConvertedTemperatureForRow(row: Int){
        let degreeCelcius = temperatureRange.values[row]
        temperatureLabel.text = "\(converter.degreesFarenhite(_degreeCelcius: degreeCelcius)) F"
        
        
    }
    
    func saveSelectedRow(row: Int){
        
        let defaults = UserDefaults.standard
        defaults.set(row, forKey: userDefaultsLastRowKey)
        defaults.synchronize()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

