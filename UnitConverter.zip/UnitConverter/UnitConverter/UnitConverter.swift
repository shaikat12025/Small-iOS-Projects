//
//  UnitConverter.swift
//  UnitConverter
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import Foundation

class UnitConverter{
    func degreesFarenhite(_degreeCelcius: Int) -> Int{
        return Int(1.8*Float(_degreeCelcius) + 32.0)
    }
    
}
