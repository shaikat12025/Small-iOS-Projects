//
//  SpaceAdventure.swift
//  SpaceAdventure
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import Foundation

class SpaceAdventure {
    let planetarySystem : PlanetarySystem
    init(planetarySystem: PlanetarySystem) {
        self.planetarySystem = planetarySystem
    }


func start(){
    displayIntroduction()
    greetAdventurer()
    if (!planetarySystem.planet.isEmpty){
        print("Let's go on an adventure!")
        determineDestination()
    }
    
}

fileprivate func displayIntroduction(){
    print("Welcome to the \(planetarySystem.name)!")
    print("There are \(planetarySystem.planet.count) plants to explore.")
}

fileprivate func responsePrompt(_ prompt: String) -> String{
    
    print(prompt)
    return getln()
}

fileprivate func greetAdventurer(){
    let name = responsePrompt("What is your name?")
    print("Nice to meet , \(name). My name is shaikat. I'm an old friend of Siri.")
}

fileprivate func determineDestination(){
    
    var decision = "" // start with empty string
    while !(decision == "Y" || decision == "y" || decision == "N" || decision == "n") {
        decision = responsePrompt("Shall I randomly choose a planet for you to visit? (Y or N)")
        if decision == "Y" || decision == "y"{
            if let planet = planetarySystem.randomPlanet{
                visit(planet.name)
            }
            else{
                print("Sorry, but there is no planets in this system.")
            }
            
    }
        else if decision == "N" || decision == "n"{
            
            let planetName = responsePrompt("Ok, name the planet you would like to visit.")
            visit(planetName)
}
        else{
            print("Sorry, I didn't get that.")
            }
    }
}

fileprivate func visit(_ planetName:String){
    print("Travelling to \(planetName) ...")
    for planet in planetarySystem.planet{
        if planetName == planet.name{
            print("Arrived at \(planet.name). \(planet.description)")
        }
    }
}

}


