//
//  HelperFunctions.swift
//  SpaceAdventure
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import Foundation

// Wait for the user to type something in the console, and return what
// they type as a String with the trailing newline character removed.

func getln() -> String{
    
    let standerdInput = FileHandle.standardInput
    
    var input = NSString(data: standerdInput.availableData, encoding: String.Encoding.utf8.rawValue)
    
    input = input!.trimmingCharacters(in: CharacterSet.newlines) as NSString
    
    return input! as String
    
}
