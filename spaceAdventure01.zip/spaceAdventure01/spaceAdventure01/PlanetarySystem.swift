//
//  PlanetarySystem.swift
//  SpaceAdventure
//
//  Created by BinaryVentures_Sadid on 12/31/17.
//  Copyright © 2017 BinaryVentures_Sadid. All rights reserved.
//

import Foundation

class PlanetarySystem {
    let name: String
    let planet: [Planet]
    var randomPlanet: Planet? {
        if planet.isEmpty{
            return nil
        }
        else{
            let index = Int(arc4random_uniform(UInt32(planet.count)))
            return planet[index]
        }
    }
    
    
    init(name:String, planets: [Planet]){
        
        self.name = name
        self.planet = planets
    }
    
}
