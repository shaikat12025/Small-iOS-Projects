//
//  RestURL.swift
//  RSSReader
//
//  Created by BinaryVentures_Sadid on 1/10/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import Foundation
public class RestURL : NSObject {

    
    static let sharedInstance = RestURL()
    
    //mark: BaseURL
    private var baseURL = "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/"
    
    // URLBody
    public var topSong = "topsongs/limit=1/json"
    public var topAlbums = "topalbums/limit=1/json"
    public var topPaidApplications = "toppaidapplications/limit=1/json"
    public var topMovies = "topMovies/limit=1/json"
    
    
    override init() {
        topSong = baseURL + topSong
       // print(topSong)
        
        topAlbums = baseURL + topAlbums
        
        topPaidApplications = baseURL + topPaidApplications
        
        topMovies = baseURL + topMovies
        
        
        
    }



}
