//
//  TopMoviesViewController.swift
//  RSSReader
//
//  Created by BinaryVentures_Sadid on 1/10/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit
import ObjectMapper
import SDWebImage
import Alamofire

class TopMoviesViewController: UIViewController {

    
    var topMoviesImageURL = ""
    
    @IBOutlet weak var titleName: UILabel!
    
    @IBOutlet weak var artistLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getTopMovies()

        // Do any additional setup after loading the view.
        topMoviesImageURL = "http://is2.mzstatic.com/image/thumb/Video118/v4/e3/44/96/e3449659-85f9-e60a-09ce-58528138afd9/pr_source.lsr/170x170bb-85.jpg"
        
        imageView.sd_setImage(with: URL(string: topMoviesImageURL), placeholderImage: UIImage(named: "placeholder.png"))
    }

    func getTopMovies() {
        let url  = RestURL.sharedInstance.topMovies
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON
            { response in
                
                print(response)
                if response.result.value != nil{
                    switch response.result{
                    case .success:
                        
                        if let root = response.result.value as? [String: Any]!{
                            print(root)
                            
                            if let feed = root["feed"] as? [String: Any]!{
                                print(feed)
                                
                                if let entry = feed["entry"] as! [String:Any]!{
                                    if let artist = entry["im:name"] as! [String:Any]!{
                                        let label = artist["label"] as! String
                                        print(label)
                                        self.artistLabel.text = label
                                    }
                                    if let title = entry["title"] as! [String:Any]!{
                                        let titleName = title["label"] as! String
                                        print(titleName)
                                        self.titleName.text = titleName
                                    }
                                    
                                }
                                
                                
                            }
                            
                        }
                        
                        
                        
                    case .failure(let error):
                        print(error)
                    }
                }
                
                
                
        }
    }
    
    
    
}
