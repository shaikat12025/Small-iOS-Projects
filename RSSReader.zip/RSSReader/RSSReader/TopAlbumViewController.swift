//
//  TopAlbumViewController.swift
//  RSSReader
//
//  Created by BinaryVentures_Sadid on 1/10/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import ObjectMapper

class TopAlbumViewController: UIViewController {
    
    
var topAlbumImageURL = ""
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var artistLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.getTopAlbum()
        
        topAlbumImageURL = "http://is3.mzstatic.com/image/thumb/Music128/v4/c1/7b/a9/c17ba975-34aa-ee68-d3c9-e1db840fa06b/075679886613.jpg/170x170bb-85.jpg"
       
        imageView.sd_setImage(with: URL(string: topAlbumImageURL), placeholderImage: UIImage(named: "placeholder.png"))
    }

    func getTopAlbum() {
        let url  = RestURL.sharedInstance.topAlbums
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON
            { response in
                
                print(response)
                if response.result.value != nil{
                    switch response.result{
                    case .success:
                        
                        if let root = response.result.value as? [String: Any]!{
                            print(root)
                            
                            if let feed = root["feed"] as? [String: Any]!{
                                print(feed)
                                
                                if let entry = feed["entry"] as! [String:Any]!{
                                    if let artist = entry["im:artist"] as! [String:Any]!{
                                        let label = artist["label"] as! String
                                        print(label)
                                        self.artistLabel.text = label
                                    }
                                    if let title = entry["title"] as! [String:Any]!{
                                        let titleName = title["label"] as! String
                                        print(titleName)
                                        self.titleLabel.text = titleName
                                    }
                                    
                                }
                                
                                
                            }
                            
                        }
                        
                        
                        
                    case .failure(let error):
                        print(error)
                    }
                }

        
        
    }
    }
    
    

}
