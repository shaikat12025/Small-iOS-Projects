//
//  TopMediaViewController.swift
//  RSSReader
//
//  Created by BinaryVentures_Sadid on 1/7/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import ObjectMapper


class TopMediaViewController: UIViewController {
    


    var songImageURL = ""
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    
    override func viewDidLoad() {
       // super.viewDidLoad()
        self.GetTopSong()
        
        
        songImageURL = "http://is1.mzstatic.com/image/thumb/Music118/v4/58/88/f7/5888f751-c95f-ba5e-2524-377b76b129ac/075679878892.jpg/170x170bb-85.jpg"
        
        imageView.sd_setImage(with: URL(string: songImageURL), placeholderImage: UIImage(named: "placeholder.png"))
        
    }


    
    func GetTopSong(){
        
        let url  = RestURL.sharedInstance.topSong
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON
            { response in
                
                print(response)
                if response.result.value != nil{
                    switch response.result{
                    case .success:
                        
                if let root = response.result.value as? [String: Any]!{
                    print(root)
                    
                    if let feed = root["feed"] as? [String: Any]!{
                        print(feed)
                        
                        if let entry = feed["entry"] as! [String:Any]!{
                            print(entry)
                            if let artist = entry["im:artist"] as! [String:Any]!{
                                print(artist)
                                
                                 let label = artist["label"] as! String
                                    print(label)
                                self.artistLabel.text = label
                                
                            
                                if let title = entry["title"] as! [String:Any]!{
                                    let titleName = title["label"] as! String
                                    print(titleName)
                                    self.titleLabel.text = titleName
                                }
                                
                                
                            }
                        }
                        
                        
                    }
                    
                    }
                    
                
                
                    case .failure(let error):
                    print(error)
                }
                }
                

                else{
                    
                }
            
        }
            
        }

    
}
