//
//  TopApplicationViewController.swift
//  RSSReader
//
//  Created by BinaryVentures_Sadid on 1/10/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit
import ObjectMapper
import Alamofire
import SDWebImage

class TopApplicationViewController: UIViewController {

    var topApplicationImageURL = ""
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var artistLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.getTopApplication()
        
        // Do any additional setup after loading the view.
        topApplicationImageURL = "http://is2.mzstatic.com/image/thumb/Purple118/v4/c2/f5/22/c2f5220d-b3b1-70bc-d2cc-1cdf00506aa9/mzl.calnzhhz.png/100x100bb-85.png"
        
        imageView.sd_setImage(with: URL(string: topApplicationImageURL), placeholderImage: UIImage(named: "placeholder.png"))
    }

    func getTopApplication() {
        let url  = RestURL.sharedInstance.topPaidApplications
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON
            { response in
                
                print(response)
                if response.result.value != nil{
                    switch response.result{
                    case .success:
                        
                        if let root = response.result.value as? [String: Any]!{
                            print(root)
                            
                            if let feed = root["feed"] as? [String: Any]!{
                                print(feed)
                                
                                if let entry = feed["entry"] as! [String:Any]!{
                                    if let artist = entry["im:name"] as! [String:Any]!{
                                        let label = artist["label"] as! String
                                        print(label)
                                        self.artistLabel.text = label
                                    }
                                    if let title = entry["title"] as! [String:Any]!{
                                        let titleName = title["label"] as! String
                                        print(titleName)
                                        self.titleLabel.text = titleName
                                    }
                                    
                                }
                                
                                
                            }
                            
                        }
                        
                        
                        
                    case .failure(let error):
                        print(error)
                    }
                }
                
                
                
        }
    }
    
    
    
}
