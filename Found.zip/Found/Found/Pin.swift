//
//  Pin.swift
//  Found
//
//  Created by BinaryVentures_Sadid on 1/6/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import Foundation
import MapKit

class Pin: NSObject, MKAnnotation{
    
    let coordinate: CLLocationCoordinate2D
   
    
    init(coordinate: CLLocationCoordinate2D){
        self.coordinate = coordinate
    }
    
    
}
